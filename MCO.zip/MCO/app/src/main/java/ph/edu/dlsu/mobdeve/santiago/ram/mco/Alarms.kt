package ph.edu.dlsu.mobdeve.santiago.ram.mco

data class Alarms(
    var alarmname: String, var alarmtime: String
)